// Select HTML elements

let elForm=document.querySelector('.user_form');
let elUserName=document.querySelector('.user_name');
let elUserSurname=document.querySelector('.user_surname');
let elUserAge=document.querySelector('.user_age');
let elUserIsMarried=document.querySelector('.user_is_married');

// Submit HTML elements
// ========================//

function validatorUserName() {
   let userNameValue=elUserName.value.trim();
   elUserName.value=null;
   if(!(userNameValue>='a' && userNameValue<='z' || userNameValue>='A' && userNameValue<='Z')) {
      return;
   }
   return userNameValue;
}

// ========================//

function validatorUserSurname() {
   let userSurnameValue=elUserSurname.value.trim();
   elUserSurname.value=null;
   if(!(userSurnameValue>='a' && userSurnameValue<='z' || userSurnameValue>='A' && userSurnameValue<='Z')) {
      return;
   }
   return userSurnameValue;
}

// ========================//

function validatorUserAge() {
   let userAgeValue=Number(elUserAge.value.trim());
   elUserAge.value=null;
   if(!(userAgeValue>=0 && userAgeValue<=150)) {
      return;
   }
   return userAgeValue;
}

// ========================//

function validatorUserIsMarried() {
   let userIsMarriedValue=elUserIsMarried.value.trim();
   elUserIsMarried.value=null;
   if(!(userIsMarriedValue==='yes' || userIsMarriedValue==='no')) {
      return;
   } 
   return userIsMarriedValue;
}
let userDataSet=[];
elForm.addEventListener('submit', function(evt) {
   evt.preventDefault();
   
   let userData={
      name: validatorUserName(),
      surname: validatorUserSurname(),
      age: validatorUserAge(),
      isMarried: validatorUserIsMarried(),
   };
   userDataSet.push(userData);
   console.log(userDataSet);
   // console.log(userData);
   // console.log(validatorUserName());


});
   